| experiment | split | fid50k | is_mean | is_std | paper_fid50k | fid_abs_error |
| --- | --- | --- | --- | --- | --- | --- |
| inpainting_uncoupled | valid | 434.4232 | 1.5156 | 0.1823 | 1.3500 | 433.0732 |
| inpainting_dependent | valid | 432.6827 | 1.5774 | 0.1269 | 1.1300 | 431.5527 |
| superres_dependent | train | 432.2889 | 1.2668 | 0.0331 | 2.1300 | 430.1589 |
| superres_dependent | valid | 434.1784 | 1.2668 | 0.0331 | 2.0500 | 432.1284 |