# PaperBench-Style Reproduction Report

- Overall score: **68.00 / 100**
- Persistent root: `/AutoDL-pub/paperbench_si_ddc`
- Image output folder: `/AutoDL-pub/paperbench_si_ddc/collected_results/image/outputs_image`

## Dimension Scores

- Code completeness: 100.00
- Model fidelity: 40.00
- Experiment reproducibility: 100.00
- Visual similarity: 100.00
- Quantitative metric error: 0.00
- Engineering completeness: 100.00

## Deductions

- Missing checkpoint coverage: 0.00
- Missing figure coverage: 0.00
- Metric gap penalty: 100.00

## Outputs

- Metrics CSV: `/AutoDL-pub/paperbench_si_ddc/metrics/reproduction_metrics.csv`
- Metrics Markdown: `/AutoDL-pub/paperbench_si_ddc/metrics/reproduction_metrics.md`
- Checkpoint `inpainting_uncoupled`: `/AutoDL-pub/paperbench_si_ddc/checkpoints/inpainting_uncoupled.pt`
- Checkpoint `inpainting_dependent`: `/AutoDL-pub/paperbench_si_ddc/checkpoints/inpainting_dependent.pt`
- Checkpoint `superres_dependent`: `/AutoDL-pub/paperbench_si_ddc/checkpoints/superres_dependent.pt`

## Summary

- The project keeps the paper's U-Net family fixed through lucidrains' implementation.
- The AutoDL pipeline trains the required ImageNet inpainting and super-resolution tasks.
- Figure 3 to Figure 7 style artifacts, metrics, reports, and archives are generated automatically.
- The quantitative score depends on the actual GPU run and sampled outputs.